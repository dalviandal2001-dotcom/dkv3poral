# Panduan: Membuat APK DKV 3 Portal tanpa Android Studio

Semua dilakukan lewat browser. Tidak perlu install apa pun di laptop.

## Tahap 1 — Buat akun GitHub
1. Buka https://github.com/signup
2. Isi email, password, username. Verifikasi email Anda.

## Tahap 2 — Buat repository
1. Setelah login, klik tombol **+** (pojok kanan atas) → **New repository**.
2. Repository name: `dkv3-portal`
3. Pilih **Public** (lebih aman untuk kuota build gratis).
4. Centang **Add a README file** (supaya repository tidak kosong).
5. Klik **Create repository**.

## Tahap 3 — Unggah file proyek
1. Ekstrak file `DKV3-Portal-APK.zip` di laptop sampai muncul folder berisi
   `app`, `.github`, `build.gradle`, `settings.gradle`, dll.
   (Jika folder `.github` tidak terlihat di Mac, tekan Cmd+Shift+. untuk menampilkan file tersembunyi.)
2. Di halaman repository, klik **Add file** → **Upload files**.
3. Buka isi folder hasil ekstrak, **pilih SEMUA isinya** (bukan foldernya),
   lalu seret ke halaman GitHub. Pastikan folder `.github`, `app` ikut terunggah.
4. Tunggu sampai semua file selesai terunggah, lalu klik **Commit changes**.

> Jika folder `.github` gagal terunggah: klik **Add file → Create new file**,
> ketik nama `.github/workflows/build-apk.yml`, lalu salin-tempel isi file
> `build-apk.yml` dari proyek, dan klik **Commit changes**.

## Tahap 4 — Jalankan build
1. Klik tab **Actions** di repository.
2. Jika muncul tombol "I understand my workflows, go ahead and enable them", klik.
3. Build berjalan otomatis setelah upload. Atau klik **Build APK** (kiri) →
   **Run workflow** → **Run workflow**.
4. Tunggu 3–6 menit sampai ada tanda centang hijau.

## Tahap 5 — Unduh APK
1. Klik nama build yang sudah hijau.
2. Gulir ke bawah ke bagian **Artifacts**, klik **DKV3-Portal-APK**.
3. File ZIP akan terunduh. Ekstrak, di dalamnya ada `app-debug.apk`.

## Tahap 6 — Pasang di HP
1. Kirim `app-debug.apk` ke HP (WhatsApp, Google Drive, kabel USB, dll).
2. Buka file di HP. Jika diminta, izinkan **Install dari sumber tidak dikenal**.
3. Tekan **Install**, lalu buka aplikasi **DKV 3 Portal**.

## Jika build gagal (tanda silang merah)
Klik build yang gagal → klik langkah yang bertanda merah → salin pesan error,
lalu kirim ke saya agar saya perbaiki.

## Catatan penting
- **Perlu internet**: tampilan memakai Tailwind, FontAwesome, Alpine.js, dan Google Fonts
  dari internet (sama seperti website asli). Tanpa internet, tampilan tidak termuat.
  Jika ingin bisa offline, minta saya untuk menyatukan semua library ke dalam aplikasi.
- **Data tersimpan di HP masing-masing**: perubahan Mode Admin (kas, siswa, aturan, struktur)
  disimpan di penyimpanan lokal aplikasi, sama seperti di browser. Tidak tersinkron antar HP,
  dan hilang jika aplikasi di-uninstall atau data aplikasi dihapus.
- **Mengubah isi website**: edit file `app/src/main/assets/index.html` di GitHub
  (klik file → ikon pensil → Commit), build akan berjalan otomatis lagi.
- APK ini bertipe *debug* (tertanda otomatis), cukup untuk dipasang dan dibagikan ke teman sekelas.
  Untuk Play Store diperlukan APK *release* bertanda tangan khusus.
